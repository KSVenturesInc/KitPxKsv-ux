describe("jsdoc/borrow", function() {
    //TODO
});