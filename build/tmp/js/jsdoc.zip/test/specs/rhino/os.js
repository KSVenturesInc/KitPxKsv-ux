/*global describe: true */
describe("os", function() {
	// TODO
});