/** @member */
var x;

/** @var foobar */
/** @var {string} baz */
