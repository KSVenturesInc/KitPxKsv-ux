/** @name dimensions */

var width = 12