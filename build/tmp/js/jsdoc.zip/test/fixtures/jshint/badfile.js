foo();

function foo() {}
