/**
 * @name virtual
 */

var foo = "bar";

/**
 * @foo bar
 */
var test = "tada";