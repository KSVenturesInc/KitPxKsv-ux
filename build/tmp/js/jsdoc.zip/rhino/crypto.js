module.exports = require('crypto-browserify');
